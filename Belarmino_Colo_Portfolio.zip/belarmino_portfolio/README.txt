BELARMINO COLO — PORTFOLIO WEBSITE
=================================

FICHEIRU:
- index.html : website portfolio kompletu (HTML, CSS, JavaScript iha ficheiru ida).

OINSÁ ATU HAREE IHA LAPTOP:
1. Download no ekstrái ZIP ne'e.
2. Tama ba pasta belarmino_portfolio.
3. Klik-rua iha index.html. Website sei loke iha Chrome, Edge ka Firefox.
4. Atu edita kódigu, instala Visual Studio Code (VS Code), loke pasta no klik index.html.

ATU HATUDU ONLINE HO LINK:
Website seidauk publika online. Atu hetan link ne'ebé ema seluk bele asesu:
1. Kria konta GitHub.
2. Kria repository foun (por ezemplu: belarmino-portfolio).
3. Upload index.html ba repository.
4. Iha Settings > Pages, hili deploy husi branch main no pasta /(root), depois Save.
5. Bainhira publika, GitHub sei fó link hanesan https://username.github.io/belarmino-portfolio/
   (username no link loos sei depende ba ita-nia konta/repository).

IMPORTANTE:
- Troka informasaun edukasaun ho dadus loos.
- Troka email placeholder iha JavaScript ho email loos antes uza form kontaktu.
- Projetu sira hatudu hanesan deskrisaun portfolio; atualiza tuir estadu no rezultadu real.
- Website ne'e responsivu ba laptop no telemóvel.
